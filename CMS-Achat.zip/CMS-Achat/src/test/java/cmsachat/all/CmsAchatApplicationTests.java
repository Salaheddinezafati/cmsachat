package cmsachat.all;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsAchatApplicationTests {

	@Test
	void contextLoads() {
	}

}

package cmsachat.all.dto;

public class AdminDTO {

}

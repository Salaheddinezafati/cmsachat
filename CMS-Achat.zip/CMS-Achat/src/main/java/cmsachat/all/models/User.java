package cmsachat.all.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "user")
public class User {

	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private long id;
	
	private String email;
	
	private String password;
	
	@OneToOne
	private Admin admin;
	
	@OneToOne
	private Collaborator collaborator;
	
	@OneToOne
	private Manager manager;
	
	@OneToOne
	private UserAprovel useraprovel;

	@OneToOne
	private Role role;
	
	
	
}

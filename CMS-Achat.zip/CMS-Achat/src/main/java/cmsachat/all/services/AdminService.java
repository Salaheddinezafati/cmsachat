package cmsachat.all.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cmsachat.all.models.Groupe;
import cmsachat.all.models.User;
import cmsachat.all.repository.GroupeRepo;
import cmsachat.all.repository.UserRepo;

@Service
public class AdminService {
	
	@Autowired
	private GroupeRepo groupeRepo;
	@Autowired
	private UserRepo userRepo;
	
	public Groupe AddGroupe(Groupe groupe) {
			return groupeRepo.save(groupe);
	}
	
	public List<Groupe> GetAllGroups() {
		return groupeRepo.findAll();
	}
	
	public User AddUser(User User) {
		return userRepo.save(User);
	}
	
	public List<User> GetAllUsers() {
		return userRepo.findAll();
	}
	
	
}

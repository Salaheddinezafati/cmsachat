package cmsachat.all.security;

public class ConfigSecurity {

}

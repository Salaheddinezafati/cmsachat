package cmsachat.all.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cmsachat.all.models.Groupe;
import cmsachat.all.models.User;
import cmsachat.all.services.AdminService;

@RestController
@RequestMapping("/api")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@PostMapping("/addgroupe")
	public Groupe addNewGroupe(Groupe groupe) {
		return adminService.AddGroupe(groupe);
	}

	@PostMapping("/adduser")
	public User addNewUser(User User) {
		return adminService.AddUser(User);
	}
	
	@GetMapping("/allusers")
	public List<User> getAllUsers(){
		return adminService.GetAllUsers();
	}
	
	@GetMapping("/allgroups")
	public List<Groupe> getAllGroups(){
		return adminService.GetAllGroups();
	}

}

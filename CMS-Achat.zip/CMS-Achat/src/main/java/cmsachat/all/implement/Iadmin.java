package cmsachat.all.implement;

public class Iadmin {

}
